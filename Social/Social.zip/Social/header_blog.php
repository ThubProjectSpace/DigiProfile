<?


// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE BLOG LANGUAGE FILE
include "./lang/lang_".$global_lang."_blog.php";

// INCLUDE BLOGS CLASS FILE
include "./include/class_blog.php";

// INCLUDE BLOGS FUNCTION FILE
include "./include/functions_blog.php";

?>