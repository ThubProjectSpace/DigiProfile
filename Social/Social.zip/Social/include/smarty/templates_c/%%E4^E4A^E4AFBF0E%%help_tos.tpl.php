<?php /* Smarty version 2.6.14, created on 2012-03-13 06:37:42
         compiled from help_tos.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<table class='tabs' cellpadding='0' cellspacing='0'>
<tr>
<td class='tab0'>&nbsp;</td>
<td class='tab2' NOWRAP><a href='help.php'><?php echo $this->_tpl_vars['help_tos1']; ?>
</a></td>
<td class='tab'>&nbsp;</td>
<td class='tab1' NOWRAP><a href='help.php'><?php echo $this->_tpl_vars['help_tos2']; ?>
</a></td>
<td class='tab'>&nbsp;</td>
<td class='tab2' NOWRAP><a href='help_contact.php'><?php echo $this->_tpl_vars['help_tos3']; ?>
</a></td>
<td class='tab3'>&nbsp;</td>
</tr>
</table>

<div class='page_header'><?php echo $this->_tpl_vars['help_tos4']; ?>
</div>

<?php echo $this->_tpl_vars['terms_of_service']; ?>


<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>