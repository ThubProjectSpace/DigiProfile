<?php /* Smarty version 2.6.14, created on 2012-03-13 06:05:54
         compiled from footer.tpl */ ?>
<hr>
<div class='ad_bottom' style='display: block; visibility: visible;'>
  <?php echo $this->_tpl_vars['ads']->ad_bottom; ?>

</div>

</td> 
<?php if ($this->_tpl_vars['ads']->ad_right != ""): ?><td class='ad_right' width='1' style='display: table-cell; visibility: visible;'><?php echo $this->_tpl_vars['ads']->ad_right; ?>




</td><?php endif; ?>
</tr>
</table>
 Copy Right 2011-2012 St. Philomena College, Puttur
 <br />
 <h4><a href="admin">Administrator Login</a></h4>
</body>
</html>