<?php /* Smarty version 2.6.14, created on 2012-03-03 01:36:06
         compiled from admin_footer.tpl */ ?>
</td>
</tr>
</table>

<br><br>

</body>
</html>