<?php /* Smarty version 2.6.14, created on 2012-03-03 02:31:32
         compiled from help.tpl */ ?>
This is help page