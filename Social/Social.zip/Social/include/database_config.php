<?


$database_host = "localhost";


$database_username = "root";


$database_password = "";


$database_name = "socialnetworking";


?>